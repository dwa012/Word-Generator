package hashtable;

import nhUtilities.containers2.List;
import nhUtilities.containers2.Iterator;
import nhUtilities.containers2.LinkedList;

/**
 * Author:  Daniel Ward
 * ID:      2396535
 * Class:   CSCi 2125
 * Date:    April 26, 2010
 *
 * This class models a Hash Table. The table is based on keys and value that
 * are associated to each other. The hashing funciton is from
 * http://www.serve.net/buz/hash.adt/java.008.html
 */
public class HashTable<Key,Value> extends AbstractDictionary<Key,Value>
{
    private List<Pair<Key,Value>>[] table;
    private int cells;//the number of cells in the table

    /**
     * Will itialize the table with no entries in the table.
     *
     * Require:
     *          population >= 0
     * Ensure:
     *          Will create a new empty table with no entries and the
     *          size will be popultaion/5
     */
    public HashTable(int populationSize)
    {
        cells = populationSize/5;
        clear();
    }

    /**
     * Will add a key and its value to the table. If the key is alrady in
     * the table then its value will be reaplced with the new value
     *
     * Require:
     *         key and value have no restrictions
     * Ensure:
     *          Will add key and value to the table, if the key exists
     *          then old.key -> old.value == old.key -> new.value
     */
    public void add(Key key, Value value)
    {
        //hash to find the locaiton in the table
        int location = location(key);

        //if the cell is null create a new LinkedList
        if(table[location] == null)
            table[location] = new LinkedList<Pair<Key,Value>>();
        
        //get the iterator for the List that is in the cell
        Iterator<Pair<Key,Value>> iter = table[location].iterator();

        //flag to see if the key is found
        boolean found = false;

        //traverse the List in the cell to find the key. Will end
        //when the end of the list is reached or the key is found.
        while(!iter.done() && found == false)
        {
            //get the pair
            Pair<Key,Value> p = iter.get();

            //if the key is found, then replace the value
            //with the new one
            if(p.getKey().equals(key))
            {
                p.setValue(value);
                found = true;
            }
            iter.advance();
        }//end while

        //add the pair to the Linked list contaitned in the cell if the
        //List does not have the key already
        if(found == false)
            table[location].add(0, new Pair<Key,Value>(key,value));
        
    }

    /**
     * Will return a value that is associated by the given key.
     *
     * Require:
     *          That the key is contained in the dictionary
     * Ensure:
     *          If the key is in the dictionary then it will return
     *          its associated value. If the key is not in the diciotnary
     *          then it will retunr a null value.
     */
    public Value get(Key key)
    {
        Value result = null;

        //get the cell that the key should be located  at
        List<Pair<Key,Value>> cell = table[location(key)];

        //if the cell conatines entries
        if(cell != null)
        {
            //get the iterator for the List that is in the cell
            Iterator<Pair<Key,Value>> iter = cell.iterator();

            //traverse the List in the cell to find the key. Will end
            //when the end of the list is reached or the key is found.
            while(!iter.done() && result == null)
            {
                //get the pair
                Pair<Key,Value> p = iter.get();

                //if the key is found, then set result as the value
                if(p.getKey().equals(key))
                    result = p.getValue();

                iter.advance();
            }//end while
        }//end if
        
        return result;
    }

    /**
     * Will clear all the entries in the table
     *
     * Ensure:
     *          Will table will conatin no entries
     */
    public void clear()
    {
        table = new LinkedList[cells];
        //should be declared as a genreic arry creation
        //(LinkedList<Pair<Key,Value>>)new Object[cells];
        //gives me a runtime error if declared as above
    }

    /**
     * Will return the total cells in the table. The num if cells in the table
     * does not reflecty the capacity of the table
     *
     * Ensure:
     *          Will return the total number of cells in the table >= 0
     * @return
     */
    public int numOfCells()
    {
        return cells;
    }

    /**
     * Will find the location of the cell relative to the key
     *
     * Ensure:
     *          Will return a location in the table based on the hashing of
     *          the key. The value has already been scaled to the size of
     *          the table.
     */
    private int location(Key key)
    {
        long hash = HashUtil.hash(key.hashCode()+"");
        return (int)(hash%cells);//typecast as in int and scale
    }
    
    public Iterator<List<Pair<Key,Value>>> cellIterator()
    {
        return new ListIterator();
    }

    /**
     * This is an iterator class that traverse the cells of the table only.
     * It will return the List that is contained in the cell only.
     */
    private class ListIterator extends AbstractIterator<List<Pair<Key,Value>>>
    {
        //the current cell in the table
        private int current;

        /**
         * Creates a new iterator to traverse the table.
         *
         * Ensure:
         *          Creates a new iterator that and the current location is set
         *          to the beginning of the table
         */
        public ListIterator()
        {
            reset();
        }

        /**
         * Resets the iterator back to the beginning.
         *
         * Ensure:
         *          Will set the itereator back at the beginning of the table
         */
        public void reset()
        {
            current = 0;
        }

        /**
         * Will move the iterator along the table
         *
         * Ensure:
         *          Will move to the iterator to the next cell, which is not
         *          necesarily the next entry in the table.
         */
        public void advance()
        {
            current++;
        }

        /**
         * Will check to see of the iterator has rachead the end of the table
         *
         * Ensure:
         *          Will return true is the iterator has reached the end of
         *          the table, otherwise will return false.
         */
        public boolean done()
        {
            return current == HashTable.this.cells;
        }

        /**
         * Will return the List that is contained in the cell that the iterator
         * is at.
         *
         * Ensure:
         *          Will return a List<Pair<Key,Value>> that is contained
         *          in the cell at the current iterator location. f the cell
         *          is empty, then the return may be a null value.
         */
        public List<Pair<Key,Value>> get()
        {
            return HashTable.this.table[current];
        }
    }
}
