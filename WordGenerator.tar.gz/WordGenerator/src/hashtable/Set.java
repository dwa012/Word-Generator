/**
 * Author           Daniel Ward
 * ID               2396535
 * Class            CSCI 2125
 * Date Created     February 22, 2010
 * Last Modified    March 22, 2010
 *
 * This interface models a Set of elements and common operations that are
 * performed on Sets.
 * This interface uses the Iterator class created
 * by Dr. Jamie Nino.
 */
public interface Set<Element> extends Iterable<Element>
{
    /**
     * Returns true if the element is in the set
     *
     * Require:
     *          e != null
     * Ensure:
     *          Returns true if Element e is in the this, else false
     *
     * @param e
     * @return boolean
     */
    public abstract boolean isMember(Element e);

    /**
     * Returns the size of this set.
     *
     * Ensure:
     *          Returns the number of elements in the set which is >=0
     *
     * @return int
     */
    public abstract int size();

    /**
     * Returns true if the set is empty.
     *
     * Ensure:
     *          Returns true if the set is this.size() == 0, else false
     *
     * @return
     */
    public boolean isEmpty();

    /**
     * Adds Element e to the set if isMember(e) == false
     *
     * Require:
     *          e != null
     * Ensure:
     *          If old.isMember(e) == false:
     *          this.isMember(e) == true, and this.size() == old.size() + 1
     *
     * @param e
     */
    public void add(Element e);

    /**
     * Removes the specified Element e from the set
     *
     * Require:
     *          e != null
     * Ensure:
     *          If old.isMember(e) == true:
     *          this.isMember(e) == false, and this.size() == old.size() - 1
     * @param e
     */
    public void remove(Element e);

    /**
     * Returns true if the elements in this are also elements in other
     *
     * Require:
     *          other.size() >= 0
     * Ensure:
     *          Will return true if all elements contained in this
     *          are also contianed in other.
     *
     * @param other
     * @return
     */
    public boolean isContained(Set<Element> other);

    /**
     * Returns a set that contains the elements of this and the elements
     * of other.
     *
     * Require:
     *          other.size() >= 0
     * Ensure:
     *          This will be contained in result.
     *          Other will be contained in result.
     *          Any element in result will be contianed in this or other.
     *          result.size() == number of unique element in this and other.
     *
     * @param other
     * @return Set<Element>
     */
    public Set<Element> union(Set<Element> other);

    /**
     * Returns a set that contains elements that occur only in both
     * this and other
     *
     * Require:
     *          other.size() >= 0
     * Ensure:
     *          Result will contain elements that are in both this and other.
     *          Result will not contain elements that are unique to this.
     *          Result will not contain elements that are unique to other.
     *          result.size() == number of elements that are the same in
     *              this and other.
     *
     * @param other
     * @return Set<Element>
     */
    public Set<Element> intersection(Set<Element> other);

    /**
     * Will produce a set of elements that unique to this.
     *
     * Require:
     *          other.size() >= 0
     * Ensure:
     *          Result will contain elements that are unique to this and
     *              and not in other.
     *          Result will not contain elements that are contained in this
     *          AND other. Result will not contain any elements that
     *          appear in other.
     *
     * @param other
     * @return Set<Element>
     */
    public Set<Element> difference(Set<Element> other);

    /**
     * Will produce a set of elements that are in this and in other but
     * not in the intersection of this and other.
     *
     * Require:
     *          other.size() >= 0
     * Ensure:
     *          Result will contain elements that are in this and other but
     *          not in the intersection of this and other.
     *
     * @param other
     * @return Set<Element>
     */
    public Set<Element> xor(Set<Element> other);

    /**
     * Returns a copy of the container.
     *
     * Ensure:
     *          A new container is created , and the references to
     *          the elements are copied to the new container.
     *
     * @return Set<Element>
     */
    public Set<Element> copy();

    /**
     * Will return a iterator for the Set.
     *
     * Ensure:
     *          Will return an instance of an Iterator.
     * @return
     */
    public nhUtilities.containers2.Iterator<Element> iterator();
}
