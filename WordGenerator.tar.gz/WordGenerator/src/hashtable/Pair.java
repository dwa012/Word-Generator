package hashtable;

/*
 * Author:  Daniel Ward
 * ID:      2396535
 * Class:   CSCi 2125
 * Date:    April 26, 2010
 * 
 * This class models a key-value pair. It is a container that contains a key
 * and a corresponding value that are of a given type.
 */
public class Pair<Key,Value>
{
    private Key key;//holder for the first element
    private Value value;//holder of the second element

    /**
     * This will initialize the Pair with the given elements.
     *
     * Ensure:
     *          Will create a Pair with a key and a value
     */
    public Pair(Key key, Value value)
    {
        this.key = key;
        this.value = value;
    }

    /**
     * Will return the value contianed in the pair
     *
     * Ensure:
     *          Will return the vlaue stored in the the pair
     */
    public Value getValue()
    {
       return this.value;
    }

    /**
     * Will set the value contained in the pair.
     *
     * Require:
     *          Value can be any value.
     * Ensure:
     *          Will set this.value to the given value.
     */
    public void setValue(Value value)
    {
       this.value = value;
    }

    /**
     * Will return the key of the pair.
     *
     * Ensure:
     *          Will return the this.key.
     */
    public Key getKey()
    {
       return this.key;
    }
    
    /**
     * Will return a hash value for this.pair based on buzhash. A copy of the
     * HashUtil class is located at 
     * http://www.serve.net/buz/hash.adt/java.008.html
     * 
     * Ensure:
     *          Will return a long containing a hash value based on the
     *          this.key
     */
    public long hashcode()
    {
        return HashUtil.hash(key.toString());
    }
    
    /**
     * Will return a String containing the key and value of this pair.
     * 
     * Ensure:
     *          Will return a String in the form of "this.key:this.value"
     * 
     * @Override Object.toString()
     */
    public String toString()
    {
        return key.toString()+":"+value.toString();
    }

    /**
     * Will compare two pairs to see they are equal. A pair is equal to another
     * pair if this.key is equal to other.key and this.value is equal to
     * other.value
     *
     * Require:
     *          obj != null
     * Ensure:
     *          Will return true if this.key.equals(other.key) &&
     *          this.value.equals(other.value), otehrwise will return false.
     * @Override Object.equals()
     */
    public boolean equals(Object obj)
    {
        boolean result = false;

        //will ensure that obj is an instance of Pair
        if(obj instanceof Pair<?,?>)
        {
            Pair<Key,Value> other = (Pair<Key,Value>)obj;
            //unchecked cast warning:
            //ok because only comparing Pair types

            result = (this.key.equals(other.key)) &&
                                           (this.value.equals(other.value));
        }//end if

        return result;
    }
}