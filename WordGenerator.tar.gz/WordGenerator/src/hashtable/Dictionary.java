package hashtable;

/*
 * Author:  Daniel Ward
 * ID:      2396535
 * Class:   CSCi 2125
 * Date:    April 26, 2010
 *
 * This interface models a Dictionary that is based on keys and values.
 */
public interface Dictionary<Key,Value>
{
    /**
     * Will add a key and its value to the dictionary. If the key is alrady in
     * the dictionary then its value will be reaplced with the new value
     *
     * Require:
     *         key and value have no restrictions
     * Ensure:
     *          Will add key and value to the dicitonary, if the key exists
     *          then old.key -> old.value == old.key -> new.value
     */
    public void add(Key key, Value value);

    /**
     * Will return a value that is associated by the given key.
     *
     * Require:
     *          That the key is contained in the dictionary
     * Ensure:
     *          If the key is in the dictionary then it will return
     *          its associated value.
     */
    public Value get(Key key);

}
