package hashtable;

/*
 * Author:  Daniel Ward
 * ID:      2396535
 * Class:   CSCi 2125
 * Date:    April 26, 2010
 *
 * This abstract calss models a Dictionary and implements common methods.
 */
public abstract class AbstractDictionary<Key,Value> implements Dictionary<Key,Value>
{
    protected AbstractDictionary()
    {
        //left blank
    }
}
