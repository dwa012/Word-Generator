package linkedset;

import nhUtilities.containers2.List;
import nhUtilities.containers2.Iterator;
import nhUtilities.containers2.LinkedList;

/**
 * Author   Daniel Ward
 * ID       2396535
 * Class    CSCI 2125
 * Date     March 10, 2010
 *
 * This concrete class models a Set of elements that is contained in an
 * LinkedList.
 * This concrete class is a subclass of AbstractSet<Element>
 */
public class LinkedSet<Element> extends AbstractSet<Element>
{
    private List<Element> elements;

    /**
     * The constructor for LinkedSet.
     *
     * Ensure:
     *          It itializes the variables for the set.
     */
    public LinkedSet()
    {
        elements = new LinkedList<Element>();
    }

    /**
     * Returns the element which is at the given index.
     *
     * Require:
     *          i >= 0 and i < this.size()
     *
     * Ensure:
     *          Returns the element in the set that is located at i.
     *
     * @param i
     * @return
     */
    public Element elementAt(int index)
    {
        return elements.get(index);
    }

    /**
     * Returns the size of this set.
     *
     * Ensure:
     *          Returns the number of elements in the set which is >=0
     *
     * @return int
     */
    public int size()
    {
        return elements.size();
    }

    /**
     * Adds Element e to the set if isMember(e) == false
     *
     * Require:
     *          e != null
     * Ensure:
     *          If old.isMember(e) == false:
     *          this.isMember(e) == true, and this.size() == old.size() + 1
     *
     * @param e
     */
    public void add(Element e)
    {
        if(!this.isMember(e))
            elements.add(e);
    }
    

    /**
     * Removes the specified Element e from the set
     *
     * Require:
     *          e != null
     * Ensure:
     *          If old.isMember(e) == true:
     *          this.isMember(e) == false, and this.size() == old.size() - 1
     * @param e
     */
    public void remove(Element e)
    {
        if(this.isMember(e))
            elements.remove(e);
    }

    /**
     * Creates a empty concrete instance of a set.
     *
     * Ensure:
     *          Will return a concrete instance of a set.
     *          result.size() == 0;
     * @return
     */
    public Set<Element> makeSet()
    {
        return new LinkedSet<Element>();
    }

    public Iterator<Element> iterator()
    {
        return elements.iterator();
    }

}
