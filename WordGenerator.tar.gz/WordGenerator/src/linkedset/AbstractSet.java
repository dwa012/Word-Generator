package linkedset;

/** 
 * Author           Daniel Ward
 * ID               2396535
 * Class            CSCI 2125
 * Date Created     February 22, 2010
 * Last Modified    March 10, 2010
 *
 * This abstract class models a Set of elements and implements Set<Element>.
 *
 * A concrete class will need to implement the following methods:
 *
 * 		Element elementAt(int i)
 * 		Set<Element> makeSet()
 *		int size() 
 *		void add()
 *		void remove()
 */
public abstract class AbstractSet<Element> implements Set<Element>
{
    /**
     * Returns the element which is at the given index.
     * 
     * Require:
     *          i >= 0 and i < this.size()
     * 
     * Ensure:
     *          Returns the element in the set that is located at i.
     * 
     * @param i
     * @return
     */
    protected abstract Element elementAt(int i);
    
    /**
     * Creates a empty concrete instance of a set.
     * 
     * Ensure:
     *          Will return a concrete instance of a set.
     *          result.size() == 0;
     * @return
     */
    protected abstract Set<Element> makeSet();

    /**
     * Will return true of the Element e is in this set.
     * 
     * Require:
     *          e != null
     * 
     * Ensure:
     *          Returns true if the Element e is in this set, else false.
     * 
     * @param e
     * @return
     */
    public boolean isMember(Element e)
    {
        boolean result = false;//start with false
        int size = this.size();//store size locally
        int i = 0;//counter for while
        
        //search for e in the set
        while(i < size && result == false)
        {
            //iterates through each element to see if e is equal to the element
            result = this.elementAt(i).equals(e);
            i = i + 1;
        }//end while
        
        return result;
    }
    
    /**
     * Returns true if the set contains no elements.
     * 
     * Ensure:
     *          Will return true if this.size() == 0 , else false
     * @return
     */
    public boolean isEmpty()
    {
        //if size() == 0 returns true, else false
        return this.size() == 0;
    }

   /**
     * Returns true if the elements in this are also elements in other
     *
     * Require:
     *          other.size() >= 0
     * Ensure:
     *          Will return true if all elements contained in this
     *          are also contianed in other.
     *
     * @param other
     * @return
     */
    public boolean isContained(Set<Element> other)
    {
        boolean result = false;//intialize to false
        
        int size = this.size();//store size locally
        int i = 0;//counter for while
        
        result = (size <= other.size());
        
        //checks that all of elements of this are in other
        while(i < size && result == true)
        {
            //check for this.elementAt(i) NOT in other
            result = other.isMember(this.elementAt(i));
                
            i = i + 1;
        }//end while
        
        return result;
    }

    /**
     * Returns a set that contains the elements of this and the elements
     * of other.
     *
     * Require:
     *          other.size() >= 0
     * Ensure:
     *          This will be contained in result.
     *          Other will be contained in result.
     *          Any element in result will be contianed in this or other.
     *          result.size() == number of unique element in this and other.
     *
     * @param other
     * @return Set<Element>
     */
    public Set<Element> union(Set<Element> other)
    {
        //copy all elements form other to result
        Set<Element> result = other.copy();
        
        int size = this.size();//store size locally

        //traverse all elements of this set and add them to result
        for(int i = 0; i < size; i++)
            result.add(this.elementAt(i));
        
        return result;
    }

    /**
    /**
     * Returns a set that contains elements that occur only in both
     * this and other
     *
     * Require:
     *          other.size() >= 0
     * Ensure:
     *          Result will contain elements that are in both this and other.
     *          Result will not contain elements that are unique to this.
     *          Result will not contain elements that are unique to other.
     *          result.size() == number of elements that are the same in
     *              this and other.
     *
     * @param other
     * @return Set<Element>
     */
    public Set<Element> intersection(Set<Element> other)
    {
        Set<Element> result = makeSet();//make a new set

        int size = this.size();//store size locally

        //traverse the elements of this and see if they are also
        //in other, if they are in other then add to result
        for(int i = 0; i < size; i++)
        {
            //see if this.elementAt(i) is also in other
            if(other.isMember(this.elementAt(i)))
                //if element is in other AND this, add to result
                result.add(this.elementAt(i));
        }

        return result;
    }

    /**
     * Will produce a set of elements that unique to this.
     *
     * Require:
     *          other.size() >= 0
     * Ensure:
     *          Result will contain elements that are unique to this and
     *              and not in other.
     *          Result will not contain elements that are contained in this
     *          AND other. Result will not contain any elements that
     *          appear in other.
     *
     * @param other
     * @return Set<Element>
     */
    public Set<Element> difference(Set<Element> other)
    {
        Set<Element> result = makeSet();//make set
        int size = this.size();

        //traverse the element of this and see if they are contained in other
        for(int i =0; i < size; i++)
        {
            //find elements that are this but not in other, then add
            //them to result
            if(!other.isMember(this.elementAt(i)))
                result.add(this.elementAt(i));
        }//end for

       return result;
    }

    /**
     * Will produce a set of elements that are this and other but not in the
     * intersection of this and other.
     *
     * Require:
     *          other.size() >= 0
     * Ensure:
     *          Result will contain elements that are in this and other but
     *          not in the intersection of this and other.
     *
     * @param other
     * @return Set<Element>
     */
    public Set<Element> xor(Set<Element> other)
    {
        Set<Element> result = makeSet();//make set
        AbstractSet<Element> temp = (AbstractSet<Element>)other;
        //typecast to use the elementAt method

        int i = 0;//while counter
        int size = this.size();//store this size

        //transverse this to add to result
        while(i < size)
        {
            //check if this element is not in temp
            if(!temp.isMember(this.elementAt(i)))
                //if not in temp then add to result
                result.add(this.elementAt(i));

            i = i + 1;
        }//end while

        i = 0;//reset counter
        size = temp.size();//store temp size

        //tranverse other to add to result
        while(i < size)
        {
            //check if temp element is in other
            if(!this.isMember(temp.elementAt(i)))
                //if not in this then add to result
                result.add(temp.elementAt(i));

            i = i + 1;
        }//end while

       return result;
    }

    /**
     * Returns a copy of the container.
     *
     * Ensure:
     *          A new container is created , and the references to
     *          the elements are copied to the new container.
     *
     * @return Set<Element>
     */
    public Set<Element> copy()
    {
        int size = this.size();//store size locally
        
        Set<Element> result = makeSet();//make new set
        
        //copies each element reference to result
        for(int i = 0; i < size; i++)
            result.add(this.elementAt(i));
        
        return result;
    }

    /**
     * Returns a String that contains all the elements of the this set in the
     * order they are in the set.
     *
     * Ensure:
     *          Will return a String that contains all the elements in the
     *          set. Example, if the set is {1,2,3,4} the the String will
     *          be "[1,2,3,4]".
     *
     * @Override Object.toString()
     * @return
     */
    public String toString()
    {
        String result = "[";
        int size = this.size();//store size locally

        //check if the set conatins no elements
        if(size != 0)
            result = result +  this.elementAt(0);

        //iterate through the set and add the elements to result
        for(int i = 1; i < size; i++)
            result = result + "," + this.elementAt(i); 
        
        result = result + "]";
        
        return result;
    }

    /**
     * Will return true of this set and the other(obj) contain the same
     * elements an are the same size.
     *
     * Require:
     *          Object obj is instance of Set and obj size >= 0
     *
     * Ensure:
     *          Will return true if this.size() == obj.size() and
     *          all the elements in this are also in other and all the
     *          elements in other are also in this.
     *
     * @Override Object.equals(Object obj)
     * @param obj
     * @return
     */
    public boolean equals(Object obj)
    {
        boolean result = false;

        //check that obj is a instance of Set<Element>
        if(obj instanceof Set<?>)
        {
            Set other = (Set)obj;
            //unchecked cast: we already checked for instanceof Set
            //and set is defined as generic
            
            result = (this.size() == other.size()) && this.isContained(other)
                       && other.isContained(this);
        }//end if

        return result;
    }
}

