package linkedset;

import nhUtilities.containers2.Iterator;

/**
 * Author           Daniel Ward
 * ID               2396535
 * Class            CSCI 2125
 * Date Created     March 22, 2010
 * Last Modified    March 24, 2010
 *
 * This concrete class models a set of ordered elements, backed by a  circular
 * Linked List with reference to the last element.
 *
 * This class is a subclass of AbstractOrderedSet. This class also uses the
 * Iterator class created by Dr. Jamie Nino.
 */
public class OrderedLinkedSet<Element> extends AbstractOrderedSet<Element>
{
    private Node last;//reference to the last node in the set
    private int size;
    
    /**
     * The constructor for the class takes a java.util.Comparator instance.
     * This Comparator will giv the class it order by specifying how
     * given elements compare to each other.
     * 
     * Require:
     *          Comparator != null
     *          Comparator be realated to the type that is to be used
     *          by the set.
     * Ensure:
     *          Will create an empty circular linked set with a header, and use 
     *          the comparator to keep the elements in order.
     */
    public OrderedLinkedSet(java.util.Comparator<Element> comparator)
    {
        //initialize Comparator in the abstract class
        super(comparator);
        
        size = 0;//empty set
        
        //make the list circular by pointing the head to itself;
        last = new Node(null);
        last.next = last;
    }
    
    /**
     * Returns the size of this set.
     *
     * Ensure:
     *          Returns the number of elements in the set which is >= 0
     *
     * @return int
     */
    public int size()
    {
        return size;
    }

    /**
     * Adds Element element to the set if isMember(e) == false. Will add the
     * element in the set in the order given by the Comparator.
     *
     * Require:
     *          element != null
     * Ensure:
     *          If old.isMember(e) == false:
     *          this.isMember(e) == true, and this.size() == old.size() + 1
     *          element will be in the order given in the order given by
     *          the Comparator
     *
     * @param e
     */
    public void add(Element element)
    {
        Node n = new Node(element);//new node for the new element
        Node p;//temp node

        //if there is only a header
        if(size == 0)
        {
            n.next = last;
            last.next = n;
            last = n;
            size = 1;
        }//end if
        //if there is more than one element in the set
        else
        {
            p = getNode(element);

            //if the element is not in the set then add it to the set.
            if(comparator.compare(p.next.element , element) > 0)
            {
                //insert new node between previous and previous.next
                n.next = p.next;
                p.next = n;
                size = size + 1;
            }//end if

            if(comparator.compare(p.next.element , element) < 0)
            {
                n.next = p.next.next;
                p.next.next = n;
                //update the last refernce
                if(n.next.element == null)
                    last = n;
                size = size + 1;
            }//end if
        }
    }

    /**
     * Removes the specified Element element from the set
     *
     * Require:
     *          element != null
     * Ensure:
     *          If old.isMember(e) == true:
     *          this.isMember(e) == false, and this.size() == old.size() - 1
     * @param e
     */
    public void remove(Element element)
    {
        //previous node
        Node p = getNode(element);

        if(size == 0);//do nothing if the list is empty

        //if the next node after p is equal to element then remove
        else if(comparator.compare(p.next.element , element) == 0)
        {
            Node temp = p.next;//store node to be removed
            p.next = p.next.next;//update teh previous to skip it
            temp.next = null;//garbage collection
            size = size - 1;

            //if you remove the end update last
            if(p.next.element == null)
                last = p;
        }//end else if
    }

    /**
     * Will get the node prevois to the one that relates to the element given
     *
     * Require:
     *           element != null
     * Ensure:
     *          That the node returned will be a node that is previous to the
     *          node that contains an element > than the element given.
     *          If a node there is not a node element > element given then it
     *          will return the node previous to the last.
     */
    private Node getNode(Element element)
    {
        //start at the header
        Node p = last.next;

        boolean go = true;//while flag

        //traverse the set till the header is reached
        //or a node element > element given
        while(go)
        {
            //if header is after the next node then stop
            if(p.next.next.element == null)
                go = false;
            //if header is not after the next node
            else
                //if the node after next is > then stop
                if(comparator.compare(p.next.next.element , element) > 0)
                    go = false;
                //if it is not greater then move to next node
                else
                    p = p.next;
        }//end while

        return p;

    }

    /**
     * Creates a empty concrete instance of a set.
     *
     * Ensure:
     *          Will return a concrete instance of a set.
     *          result.size() == 0;
     *          result.isEmpty() == false
     *          result will have the same ordering as this
     * @return
     */
    public Set<Element> makeSet()
    {
        //new empty instance of this
        return new OrderedLinkedSet(comparator);
    }

    /**
     * Returns a copy of the container.
     *
     * Ensure:
     *          A new container is created , and the references to
     *          the elements are copied to the new container. The
     *          new container will have the same ordering as this.
     *
     * @return Set<Element>
     */
    public Set<Element> copy()
    {
        //new empty set
        OrderedLinkedSet result = new OrderedLinkedSet(comparator);
        int i = 0;

        Node t = this.last.next;//this node reference staring at the head
        Node p = result.last.next;//new set reference staring at head

        //traverse this set till the header is reached
        while(i < size)
        {
            //make a new node form element in this and link it in the result
            p.next = new Node(t.next.element);
            p = p.next;//move along result set
            t = t.next;//move along this set
            i = i + 1;
        }
        p.next = result.last;//com
        result.last = p;

        return result;
    }

    /**
     * Will return a iterator for the Set.
     *
     * Ensure:
     *          Will return an instance of an Iterator for the
     *          concrete class to traverse the elements in the set.
     * @return
     */
    public Iterator<Element> iterator()
    {
        return new OrderedLinkedSetIterator();
    }

    /**
     * This is an internal class of Iterator for the OrderedLinkedSet.
     *
     * This class implements the Iterator class created by Dr. Jamie Nino
     */
    class OrderedLinkedSetIterator<Element> implements Iterator<Element>
    {
        private Node current;//is this.last

        /**
         * Wiil creates the iterator for teh set at the first element
         * in the set.
         *
         * Ensure:
         *          will set the iterator ot the forst element at the set
         */
        public OrderedLinkedSetIterator()
        {
            reset();
        }

        /**
         * Will return the element in the node at the current position of the
         * iterator.
         *
         * Ensure:
         *          Will return the element in the node at the current position
         *          of the iterator. Will reset the iterator if the iterator
         *          was created before the set was filled.
         * @return
         */
        public Element get()
        {
            //will reset if the iterator was created before the set was filled
            if(current.element == null)
                reset();
            return (Element)current.element;
        }

        /**
         * Resets the iterator back to the beginning
         *
         * Ensure:
         *          Will place the iterator back at the beginning of the set
         */
        public void reset()
        {
            current = OrderedLinkedSet.this.last.next.next;
        }

        /**
         * Will see if the iterator has reached the end of the set
         *
         * Ensure:
         *          Will check to see if the iterator has reached the header,
         *          if it is at the end it will return true, else false.
         * @return
         */
        public boolean done()
        {
            return current.element == null;
        }

        /**
         * Will move the iterator to the next node.
         *
         * Ensure:
         *          Will move the iterator to the next node.
         */
        public void advance()
        {
            current = current.next;
        }

        /**
         * This is a method from java.util.Iterator, it will move the
         * iterator to the next node and return the element in the node.
         *
         * Ensure:
         *          Will return the element in the next node and move
         *          the iterator to the next node.
         * @return
         */
        public Element next()
        {
            Element e = (Element)current.next.element;
            this.advance();
            return e;
        }

        /**
         * Fromm java.util.Iterator, will check if there is another node in the
         * set.
         *
         * Ensure:
         *          Will see if there is any more nodes in the set.
         *          will return true if there are still more nodes, else
         *          will return fasle if the end is reached.
         * @return
         */
        public boolean hasNext()
        {
            return !this.done();
        }

        /**
         * This operation is unsupported by this implementaion
         */
        public void remove()
        {
            throw new UnsupportedOperationException("Not Implemented");
        }

        /**
         * This operation is unsupported by this implementaion
         */
        public Object clone()
        {
            throw new UnsupportedOperationException("Not Implemented");
        }

        /**
         * This operation is unsupported by this implementaion
         */
        public boolean traverses(Object container)
        {
            throw new UnsupportedOperationException("Not Implemented");
        }

        /**
         * This operation is unsupported by this implementaion
         */
        public void setEqualTo(nhUtilities.containers2.Iterator other)
        {
            throw new UnsupportedOperationException("Not Implemented");
        }
    }//end Class OrderedLinkedSetIterator
    
    /**
     * Internal class of node that contain an element and a reference
     * to the next element
     */
    private class Node
    {
        private Element element; //what is stored in the node
        private Node next; //the node after this node

        /**
         * This constuctor create a node that conatins a given Element e.
         *
         * Require:
         *          e != null
         * Ensure:
         *          Will create a new node and set this.element = e
         *          Set the this.next = NULL.
         * @param e
         */
        public Node(Element e)
        {
            element = e;
            next = null;
        }
    }//end of Class Node

}//end Class OrderedLinkedSet