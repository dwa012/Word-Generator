package linkedset;

import nhUtilities.containers2.Iterator;
/**
 * Author:  Daniel Ward
 * ID:      2396535
 * Class:   CSCi 2125
 * Date:    April 26, 2010
 *
 */
public abstract class AbstractIterator<Element> implements Iterator<Element>
{
    public boolean equals(Object obj)
    {
        new UnsupportedOperationException();
        return false;
    }
    public boolean traverses(Object container)
    {
        new UnsupportedOperationException();
        return false;
    }
    public Object clone ()
    {
        new UnsupportedOperationException();
        return false;
    }
    public void setEqualTo(Iterator other)
    {
        new UnsupportedOperationException();
    }

    public boolean hasNext()
    {
        return !this.done();
    }
    public Element next()
    {
        Element temp = this.get();
        advance();
        return temp;

    }
    public void remove()
    {
        new UnsupportedOperationException();
    }

}
