package linkedset;

import nhUtilities.containers.List;
import nhUtilities.containers.AbstractList;

/**
 * Author           Daniel Ward
 * ID               2396535
 * Class            CSCI 2125
 * Date Created     March 10, 2010
 * Last Modified    March 10, 2010
 *
 * This is a conrete class that implements a list based on a links.
 * This concrete class is a subclass of AbstractList<Element>
 * AbstractList<Element> was created be Dr. Jaime Nino.
 */
public class LinkedListHeader<Element> extends AbstractList<Element>
{
    private int size; //the size of the list
    private Node last; //a reference to the last node in the list
    private String head;

    /**
     * This constructor craeats an empty list with the variables intialized
     *
     * Ensure:
     *          this.size() == 0
     *          this.last == null
     */
    public LinkedListHeader(String head)
    {
        size = 0;
        last = null;
        this.head = head;
    }
    
    public String getHeader()
    {
        return head;
    }

    /**
     * Returns the current size of the list.
     *
     * Ensure:
     *          Will return the size >= 0 of the list
     * @return
     */
    public int size()
    {
        return size;
    }

    /**
     * Returns the node that is a the given index.
     *
     * Require:
     *          index < this.size() && index > 0
     * Ensure:
     *          Will return a refernce to the Node at the index requested.
     * @param index
     * @return
     */
    private Node getNode(int index)
    {
        Node n = last;

        int i = -1;

        //traverse the list to the node at index then end the loop
        while(i < index)
        {
            n = n.next;
            i = i + 1;
        }//end while

        return n;
    }

    /**
     * Will return the element contained in a node at index.
     *
     * Require:
     *          index < this.size() && index >= 0
     * Ensure:
     *          Will return the element contained in the node at
     *          the given index.
     * @param index
     * @return
     */
    public Element get(int index)
    {
        return getNode(index).element;
    }

    /**
     * Will return the index of the node that contains the Element e.
     *
     * Require:
     *          e != null
     * Ensure:
     *          Will traverse the list to see if the eleemnt is contained
     *          in the list. It will return the index of the first
     *          occurence in the list. Will return an integer >= 0 if the
     *          Element e is found, otherwise will return -1.
     * @param e
     * @return
     */
    public int indexOf(Element e)
    {
        int i = 0;
        int index = -1;
        Node p = last.next; //start at the 0th node

        //will traverse the list till the Element e is found.
        while(i < size && index == -1)
        {
            //if e is found the set index and end the loop
            if((p.element).equals(e))
                index = i;
            p = p.next;
            i = i + 1;
        }//end while

        return index;
    }

    /**
     * Will add the Element e to the at the index. It will move items in the
     * accordingly if index == this.size().
     *
     * Require:
     *          e != null 
     *          index <= this.size() && index >= 0
     * Ensure:
     *          Will add the Element e at the given index. If there
     *          is an element at the given index it will be pushed
     *          to index + 1, as well as all other following elements.
     *          this.size() == old.size() + 1
     *
     * @param index
     * @param e
     */
    public void add(int index, Element e)
    {
        Node t = new Node(e);

        //the special case of adding to an empty set
        if(size == 0 && index == 0)
        {
            last = t;
            t.next = last;
        }//end if

        else//the general case of this.size() > 0
        {
            Node p = getNode(index-1);
        
            t.next = p.next;
            p.next = t;

            //changes the last reference if the element is placed at the end
            if(index == size)
                last = t;
        }//end else
        
        size = size + 1;
    }

    /**
     * Will add the Element e to the end of list.
     *
     * Require:
     *          e != null
     * Ensure:
     *          Will add the Element e to the end of the list.
     *          this.size() == old.size() + 1
     *
     * @override overrides the add(Element e) in AbstractList to
     *           improve efficiency
     * @param e
     */
    public void add(Element e)
    {
        Node n = new Node(e);

        //special case if this.size() == 0
        if(size == 0)
        {
            last = n;
            n.next = last;
        }//end if
        
        else//general case of this.size > 0
        {
            n.next = last.next;
            last.next = n;
            last = n;
        }//end else
        
        size = size + 1;
    }

    /**
     * Will overwrite the element at index with the Element e
     *
     * Require:
     *          index >= 0 && index < size && e != null
     * Ensure:
     *          The element at index will be overwritten with
     *          the Element e.
     *
     * @param index
     * @param e
     */
    public void set(int index, Element e)
    {
        getNode(index).element = e;
    }

    /**
     * Will reomve the element at the given index.
     * Require:
     *          index >= 0 && index < size
     * Ensure:
     *          Will remove the element at the diven index and update
     *          the refrences.
     *          this.size() == old.size() - 1
     *
     * @param index
     */
    public void remove(int index)
    {
        Node p = null;

        //special case if one element is in the list
        if(size < 2)
        {
            last.next = null;
            last = null;
        }//end if

        else//general case for size() > 1
        {
            p = getNode(index-1);
            Node t = p.next;
            p.next = p.next.next;
            t.next = null;//garbage collection
        }//end else

        //update last reference if you remove the last element
        if(index == size - 1)
            last = p;

        size = size - 1;
    }

    /**
     * Will return a copy of this container.
     * Ensure:
     *          A new container is created , and the references to
     *          the elements are copied to the new container.
     */
    public List<Element> copy()
    {
        LinkedListHeader<Element> temp = new LinkedListHeader<Element>("");

        int i = 1;

        temp.last = new Node(last.element);//create temp.last
        temp.size = this.size;//copy size
        
        Node p = last;
        Node t = temp.last;

        //trasverse this list and create new nodes from the elements in this,
        //will then connect the references to each element
        while(i < size)
        {
            t.next = new Node(p.next.element);
            p = p.next;
            t = t.next;

            i = i + 1;
        }//end while

        t.next = temp.last;//create the final refernce to make it circular

        return temp;
    }

    /**
     * Returns a formated string that contains the elements of this.
     * 
     * Ensure:
     *          Will create a string that contains all elements is this.
     *          {1,2,3} will be "[1,2,3,]"
     * @return
     */
    public String toString ()
    {
        String s = "head: " + head + " [";
        Node p = last.next;
        int i = 0;
        
        //traverse the elements of this and add to string.
        while(i < size)
        {
            s = s + p.element.toString() + ",";
            p = p.next;
            i = i + 1;
        }//end while
        
        s = s + "]";

        return s;
    }

    /**
     * Will return true if the two lists contain the same elements and
     * are the same size, else false.
     * 
     * Require:
     *          obj be an instance of List<Element> && the List contains
     *          objects of the same type.
     * Ensure:
     *          Will return true if they contain the same elements && 
     *          this.size() == (List)obj.size()
     * 
     * @param obj
     * @return
     */
    public boolean equals(Object obj)
    {
        boolean result = false;

        //check for an instance of List
        if(obj instanceof List<?>)
        {
            List temp = (List)obj;
            //Warning: unchecked conversion
            //typcast to a List, is ok since we checked
            //that it was an instance of List

            result = (this.size == temp.size());

            int i = 0;

            //see if this elements are contained in obj, if they are not
            //then end loop early.
            while(i < size && result)
            {
                result= temp.contains(this.get(i));
                i = i + 1;
            }
        }

        return result;
    }

    public java.util.Iterator<Element> iterator()
    {
        return new LinkedListHeaderIterator<Element>();
    }

    /**
     * Internal class of node that contain an element and a reference
     * to the next element
     */
    private class Node
    {
        private Element element; //what is stored in the node
        private Node next; //the node after this node

        /**
         * This constuctor create a node that conatins a given Element e.
         *
         * Require:
         *          e != null
         * Ensure:
         *          Will create a new node and set this.element = e
         *          Set the this.next = NULL.
         * @param e
         */
        public Node(Element e)
        {
            element = e;
            next = null;
        }
    }//end of Class Node

    private class LinkedListHeaderIterator<Element> implements java.util.Iterator<Element>
    {
        Node current;

        public LinkedListHeaderIterator()
        {
            current = LinkedListHeader.this.last.next;
        }
        
        public boolean hasNext()
        {
            return !(current == last);
        }

        public Element next()
        {
            Element e = (Element)current.element;
            current = current.next;
            return e;
        }

        public void remove()
        {
            //not used
        }
    }

}//end of Class LinkedListHeader
