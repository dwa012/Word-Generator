package linkedset;

import nhUtilities.containers2.Iterator;

/** 
 * Author           Daniel Ward
 * ID               2396535
 * Class            CSCI 2125
 * Date Created     March 22, 2010
 * Last Modified    March 24, 2010
 *
 * This abstract class models a Set of ordered elements and
 * implements Set<Element>.
 *
 * A concrete class will need to implement the following methods:
 *
 * 		Set<Element> makeSet()
 *		int size() 
 *		void add()
 *		void remove()
 */
public abstract class AbstractOrderedSet<Element> implements Set<Element>
{
    //comparator used to compare elements in sets
    //needs to be initialized by a concrete class
    protected java.util.Comparator<Element> comparator;
    
    /**
     * Creates the comparator for this class
     * 
     * Ensure:
     *          Constructor creates the comparator
     */
    protected AbstractOrderedSet(java.util.Comparator<Element> comparator)
    {
        this.comparator = comparator;
    }

    /**
     * Creates a empty concrete instance of a set.
     * 
     * Ensure:
     *          Will return a concrete instance of a set.
     *          result.size() == 0;
     *          The new instance will have the same ordering as this
     * @return
     */
    protected abstract Set<Element> makeSet();

    /**
     * Will return true of the Element e is in this set.
     * 
     * Require:
     *          e != null
     * 
     * Ensure:
     *          Returns true if the Element e is in this set, else false.
     * 
     * @param e
     * @return
     */
    public boolean isMember(Element e)
    {
       Iterator<Element> iterator = this.iterator();

       boolean result = false;

       //will travese this set till it finds e
       //if it finds e then result == true
       while(!iterator.done() && result == false)
       {
            result = e.equals(iterator.get());
            iterator.advance();
       }

       return result;

    }
    
    /**
     * Returns true if the set contains no elements.
     * 
     * Ensure:
     *          Will return true if this.size() == 0 , else false
     * @return
     */
    public boolean isEmpty()
    {
        //if size() == 0 returns true, else false
        return this.size() == 0;
    }

    /**
     * Returns true if the elements in this are also elements in other
     *
     * Require:
     *          other.size() >= 0
     *          other be ordered with the same ordering as this
     * Ensure:
     *          Will return true if all elements contained in this
     *          are also contianed in other.
     *
     * @param other
     * @return
     */
    public boolean isContained(Set<Element> other)
    {
        int numEqual = 0;//counter for elements in this and in other
        boolean result = false;//loop flag
        
        Iterator<Element> thisIt = this.iterator();//iterator for this set
        Iterator<Element> otherIt = other.iterator();//iterator for other set

        //comapre sizes to see if a check of the elements is needed
        result = (this.size() <= other.size());

        //travers the elements to see if all the elements in this are also
        //in other. The loop will end if the end of either set is reached
        //or result == false
        while(!thisIt.done() && !otherIt.done() && result != false)
        {
            //compare the elements in the two sets
            int comp = comparator.compare(thisIt.get(),otherIt.get());

            //if this element < other element then this cannot be conatained
            //in other, then end the loop
            if(comp < 0)
                result = false;

            //if this element > other element then advance other
            else if(comp > 0)
                otherIt.advance();

            //if this element is an element of other then increment counter
            //and move both
            else if(comp == 0)
            {
                numEqual = numEqual + 1;
                thisIt.advance();
                otherIt.advance();
            }//end else if
        }//end while

        return result && numEqual == this.size();
    }

    /**
     * Returns a set that contains the elements of this and the elements
     * of other.
     *
     * Require:
     *          other.size() >= 0
     *          other be ordered with the same ordering as this
     * Ensure:
     *          This will be contained in result.
     *          Other will be contained in result.
     *          Any element in result will be contianed in this or other.
     *          result.size() == number of unique element in this and other.
     *
     * @param other
     * @return Set<Element>
     */
    public Set<Element> union(Set<Element> other)
    {
        Set<Element> result = makeSet();//make set
        Iterator<Element> thisIt = this.iterator();//iterator for this set.
        Iterator<Element> otherIt = other.iterator();//iterator for the other

        //will traverse both set till it reaches the end of one
        while(!thisIt.done() && !otherIt.done())
        {
            //compare the elements and store locally
            int comp = comparator.compare(thisIt.get(),otherIt.get());
            //if this element < other element
            if(comp < 0)
            {
                //add this element to result then advance this
                result.add(thisIt.get());
                thisIt.advance();
            }//end if

            //if this element > other element
            else if(comp > 0)
            {
                //add other element to result then advance other
                result.add(otherIt.get());
                otherIt.advance();
            }//end else if

            //if this element == other element
            else
            {
                //add one elemnt to result then advance both
                result.add(thisIt.get());
                thisIt.advance();
                otherIt.advance();
            }//end else
        }//end while

        //will keep filling resultt if other is larger than this
        while(thisIt.done() && !otherIt.done())
        {
            //add remaining elements of other to result
            result.add(otherIt.get());
            otherIt.advance();
        }//end while

        //will keep filling result if this is larger than  other
        while(!thisIt.done() && otherIt.done())
        {
            //add remaining elements of this to result
            result.add(thisIt.get());
            thisIt.advance();
        }//end while
        
        return result;
    }

    /**
     * Returns a set that contains elements that occur only in both
     * this and other
     *
     * Require:
     *          other.size() >= 0
     *          other be ordered with the same ordering as this
     * Ensure:
     *          Result will contain elements that are in both this and other.
     *          Result will not contain elements that are unique to this.
     *          Result will not contain elements that are unique to other.
     *          result.size() == number of elements that are the same in
     *              this and other.
     *
     * @param other
     * @return Set<Element>
     */
    public Set<Element> intersection(Set<Element> other)
    {
        Set<Element> result = makeSet();//make a new set
        
        Iterator<Element> thisIt = this.iterator();//this iterator
        Iterator<Element> otherIt = other.iterator();//other iterator

        //traverse both sets till one is finished
        while(!thisIt.done() && !otherIt.done())
        {
            //compare the current elements in both sets
            int comp = comparator.compare(thisIt.get(),otherIt.get());
            //if this elemnt is less than other then advance this
            if(comp < 0)
                thisIt.advance();
            //if this element > other elemnt then advacne other
            else if(comp > 0)
                otherIt.advance();
            //if the element is in both this and other, add to result
            //then advance both
            else
            {
                result.add(thisIt.get());
                thisIt.advance();
                otherIt.advance();
            }//end else
        }//end while

        return result;
    }

    /**
     * Will produce a set of elements that unique to this.
     *
     * Require:
     *          other.size() >= 0
     *          other be ordered with the same ordering as this
     * Ensure:
     *          Result will contain elements that are unique to this and
     *              and not in other.
     *          Result will not contain elements that are contained in this
     *          AND other. Result will not contain any elements that
     *          appear in other.
     *
     * @param other
     * @return Set<Element>
     */
    public Set<Element> difference(Set<Element> other)
    {
        Set<Element> result = makeSet();//make set
        Iterator<Element> thisIt = this.iterator();//this iterator
        Iterator<Element> otherIt = other.iterator();//other iterator

        //travers both sets to see what elements are in this
        //but not in other, then add to the result
        while(!thisIt.done() && !otherIt.done())
        {
            //compare the two elements
            int comp = comparator.compare(thisIt.get(),otherIt.get());

            //if element in this < element in other then add this element
            //to result and advance this
            if(comp < 0)
            {
                result.add((Element)thisIt.get());
                thisIt.advance();
            }

            //if element in this > element in other, then advance other
            else if(comp > 0)
                otherIt.advance();

            //if the elements are equal then advacnce both
            else
            {
                thisIt.advance();
                otherIt.advance();
            }//end else
        }//end while

        //if this.size() > other.size() then add the rest of the elements
        //from this to the result
        while(!thisIt.done())
        {
            result.add((Element)thisIt.get());
            thisIt.advance();
        }//end while

       return result;
    }

    /**
     * Will produce a set of elements that are this and other but not in the
     * intersection of this and other.
     *
     * Require:
     *          other.size() >= 0
     *          other be ordered with the same ordering as this
     * Ensure:
     *          Result will contain elements that are in this and other but
     *          not in the intersection of this and other.
     *
     * @param other
     * @return Set<Element>
     */
    public Set<Element> xor(Set<Element> other)
    {
        Set<Element> result = makeSet();//make set
        Iterator<Element> thisIt = this.iterator();//iterator for this set.
        Iterator<Element> otherIt = other.iterator();//iterator for the other

        //traverse both sets till the end of one of the sets is reached
        while(!thisIt.done() && !otherIt.done())
        {
            //compare element in this with element in other
            int comp = comparator.compare(thisIt.get(),otherIt.get());

            //if this element < other element, add this element to result
            //and advance this
            if(comp < 0)
            {
                result.add(thisIt.get());
                thisIt.advance();
            }//end if

            //if this element > other element, add other element to result
            //and advance other
            else if(comp > 0)
            {
                result.add(otherIt.get());
                otherIt.advance();
            }//end if

            //if this element == other element, advance both
            else
            {
                thisIt.advance();
                otherIt.advance();
            }//end else
        }//end while

        //if other.size() > this.size() add remaining elements in other to
        //result
        while(!otherIt.done())
        {
            result.add(otherIt.get());
            otherIt.advance();
        }//end while

        //if this.size() > other.size() add remaining elements in this to
        //result
        while(!thisIt.done())
        {
            result.add(thisIt.get());
            thisIt.advance();
        }//end while

        return result;
    }

    /**
     * Returns a copy of the container.
     *
     * Ensure:
     *          A new container is created , and the references to
     *          the elements are copied to the new container. The
     *          new container will have the same ordering as this.
     *
     * @return Set<Element>
     */
    public Set<Element> copy()
    {
        Set<Element> result = makeSet();//make new set
        Iterator<Element> iterator = this.iterator();

        //travers all the elements in this and add the elements to result
        while(!iterator.done())
        {
            result.add(iterator.get());
            iterator.advance();
        }//end while
        
        return result;
    }

    /**
     * Returns a String that contains all the elements of the this set in the
     * order they are in the set.
     *
     * Ensure:
     *          Will return a String that contains all the elements in the
     *          set. Example, if the set is {1,2,3,4} the the String will
     *          be "[1,2,3,4]".
     *
     * @Override Object.toString()
     * @return
     */
    public String toString()
    {
        StringBuilder result = new StringBuilder("[");//the string to return

        Iterator<Element> iterator = this.iterator();//iterator for this set

        //add first element to string if there is a first element
        if(!iterator.done())
            result.append(iterator.get().toString());

        iterator.advance();

        //iterate through the set and add the remaining elements to result
        while(!iterator.done())
        {
            result.append(',' +iterator.get().toString());
            iterator.advance();
        }//end while
        
        result.append("]");//finish the string
        
        return result.toString();
    }

    /**
     * Will return true of this set and the other(obj) contain the same
     * elements an are the same size.
     *
     * Require:
     *          Object obj is instance of Set and obj size >= 0
     *          obj be ordered with the same ordering as this
     *
     * Ensure:
     *          Will return true if this.size() == obj.size() and
     *          all the elements in this are also in other and all the
     *          elements in other are also in this.
     *
     * @Override Object.equals(Object obj)
     * @param obj
     * @return
     */
    public boolean equals(Object obj)
    {
        boolean result = false;//boolean to return
        Iterator<Element> thisIter = this.iterator();//iterator for this set
        Iterator<Element> otherIter;//iterator for other set

        //check that obj is a instance of Set<Element>
        if(obj instanceof Set<?>)
        {
            Set other = (Set)obj;

            otherIter = other.iterator();
            
            result = this.size() == other.size();

            //traverse both sets to see if they contain the same elements
            //will compare elements in the same position since the sets are in
            //order
            while(!thisIter.done() && result != false)
            {
                //if the elements in the both are equal continue the check
                //if they are unequal then end loop
                if(comparator.compare(thisIter.get(),otherIter.get()) == 0)
                    result = true;
                else
                    result = false;
                thisIter.advance();
                otherIter.advance();
            }//end while
                
        }//end if

        return result;
    }
}