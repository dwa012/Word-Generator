/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import linkedset.LinkedListHeader;
/**
 *
 * @author daniel
 */
public class LexDict {

    private LinkedListHeader<String>[] dictionary;
    private char[] letters;
    private java.io.File file;
    private String language;

    /**
     *
     * @param file The path to the file containing the word list
     * @param letters An array containing the letters in the alphabet
     */
    public LexDict(char[] letters,String language)
    {
        this.language = language;
        selectDictionary(language);
        this.letters = letters;
        dictionary = new LinkedListHeader[letters.length];
        readFile();

    }

    private void readFile()
    {
        try
        {
            java.util.Scanner scanner = new java.util.Scanner(file);

            for(int i = 0; i < letters.length; i++)
            {
                dictionary[i] = new LinkedListHeader(letters[i]+"");
                //System.out.println(dictionary[i].toString());
            }

            while(scanner.hasNext())
            {
                String temp = scanner.next();
                temp = temp.toUpperCase();
                dictionary[indexOf(temp.charAt(0))].add(temp);
            }


        }

        catch(java.io.FileNotFoundException e)
        {
            System.out.println("Could not open file");
        }
        //System.out.println(dictionary[0].toString());


    }

    /**
     * return -1 if word is not found and is not a prefix
     * return 0 if word is not found but is a prefix
     * return 1 if word is found and a prefix
     * return 2 if word is found and not a prefix
     * @param word
     * @return
     */
    public int lookup(String word)
    {
        int result = -1;
        String previous = "";
        int dictIndex = indexOf(word.charAt(0));
        boolean stop = false;

        java.util.Iterator<String> iter = dictionary[dictIndex].iterator();

        while(iter.hasNext() && !stop)
        {
            String temp = iter.next();

            if(temp.lastIndexOf(word) == 0)
            {
                previous = temp;
                result = 0;
                stop = true;
            }
        }

        if(word.equals(previous))
        {
            //System.out.println(word);
            result = 2;

            if(iter.hasNext())
            {
                String temp = iter.next();
                //System.out.println(temp);
                if(temp.lastIndexOf(word) == 0)
                    result = 1;
            }
                
        }

        return result;
    }

    private int indexOf(char character)
    {
        int index = -1;

        for(int i = 0; i < letters.length; i++)
        {
            if(character == letters[i])
                index = i;
        }

        return index;
    }

    private void selectDictionary(String filepath)
    {
        if(filepath.equals("ENG"))
        {
            file = new java.io.File("eng_dict.txt");
        }
        if(filepath.equals("GER"))
        {
            file = new java.io.File("ger_dict.txt");
        }
        if(filepath.equals("FRE"))
        {
            file = new java.io.File("fre_dict.txt");
        }
    }
}
